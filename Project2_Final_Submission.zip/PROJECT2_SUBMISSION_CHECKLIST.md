# Project 2 Final Submission Checklist

## Required Repository Contents
- [ ] Jupyter notebook with full workflow and outputs.
- [ ] README report at repo root (`README.md`).
- [ ] Source code files for training/evaluation/inference.
- [ ] Dependency file and setup instructions.

## 1) Alignment with Project Brief (25 pts)
- [ ] Problem statement clearly defined.
- [ ] Business/user impact explained.
- [ ] Solution directly addresses dialogue summarization use case.
- [ ] Final outputs show concise, useful summaries.

## 2) Technical Implementation (25 pts)
- [ ] Data pipeline for SAMSum loading and preprocessing is implemented.
- [ ] BERT-based encoder-decoder architecture is implemented and run.
- [ ] Training loop and model saving are functional.
- [ ] Inference examples are generated and documented.
- [ ] Optional ChatGPT baseline is included or discussed.

## 3) Evaluation and Analysis (25 pts)
- [ ] ROUGE metrics reported (R1, R2, RL, RLsum).
- [ ] At least 3 qualitative example analyses included.
- [ ] Errors/limitations identified with concrete examples.
- [ ] Improvement ideas connected to observed failures.

## 4) Documentation and Report (25 pts)
- [ ] README is professional, clear, and complete.
- [ ] Run instructions are reproducible.
- [ ] Hyperparameters and architecture choices are documented.
- [ ] Results table is complete and consistent with notebook outputs.

## Final QA Before Submitting
- [ ] Notebook runs top-to-bottom (or includes clear notes about heavy training cells).
- [ ] No absolute local paths remain in final notebook.
- [ ] No credentials/API keys are committed.
- [ ] Links in README work.
- [ ] Repository is public or shared according to submission rules.
