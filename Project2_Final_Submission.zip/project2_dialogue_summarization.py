import argparse
import json
import os
import random
from typing import Dict, List

import numpy as np
from datasets import DatasetDict, load_dataset
import evaluate
from transformers import (
    AutoTokenizer,
    DataCollatorForSeq2Seq,
    EncoderDecoderModel,
    Seq2SeqTrainer,
    Seq2SeqTrainingArguments,
)


def set_seed(seed: int = 42) -> None:
    random.seed(seed)
    np.random.seed(seed)


def load_samsum(sample_limit: int = 0) -> DatasetDict:
    ds = load_dataset("samsum")
    if sample_limit and sample_limit > 0:
        for split in ["train", "validation", "test"]:
            keep = min(sample_limit, len(ds[split]))
            ds[split] = ds[split].select(range(keep))
    return ds


def build_model_and_tokenizer() -> tuple[EncoderDecoderModel, AutoTokenizer]:
    tokenizer = AutoTokenizer.from_pretrained("bert-base-uncased")
    model = EncoderDecoderModel.from_encoder_decoder_pretrained(
        "bert-base-uncased", "bert-base-uncased"
    )

    model.config.decoder_start_token_id = tokenizer.cls_token_id
    model.config.eos_token_id = tokenizer.sep_token_id
    model.config.pad_token_id = tokenizer.pad_token_id
    model.config.vocab_size = model.config.decoder.vocab_size
    model.config.max_length = 96
    model.config.min_length = 12
    model.config.no_repeat_ngram_size = 3
    model.config.early_stopping = True
    model.config.length_penalty = 1.0
    model.config.num_beams = 4

    return model, tokenizer


def preprocess_batch(batch: Dict[str, List[str]], tokenizer: AutoTokenizer) -> Dict[str, List[List[int]]]:
    model_inputs = tokenizer(
        batch["dialogue"],
        max_length=512,
        truncation=True,
    )

    with tokenizer.as_target_tokenizer():
        labels = tokenizer(
            batch["summary"],
            max_length=96,
            truncation=True,
        )

    model_inputs["labels"] = labels["input_ids"]
    return model_inputs


def compute_metrics_builder(tokenizer: AutoTokenizer):
    rouge = evaluate.load("rouge")

    def compute_metrics(eval_pred):
        predictions, labels = eval_pred
        if isinstance(predictions, tuple):
            predictions = predictions[0]

        decoded_preds = tokenizer.batch_decode(predictions, skip_special_tokens=True)
        labels = np.where(labels != -100, labels, tokenizer.pad_token_id)
        decoded_labels = tokenizer.batch_decode(labels, skip_special_tokens=True)

        decoded_preds = [p.strip() for p in decoded_preds]
        decoded_labels = [l.strip() for l in decoded_labels]

        result = rouge.compute(
            predictions=decoded_preds,
            references=decoded_labels,
            use_stemmer=True,
        )
        return {k: round(v, 4) for k, v in result.items()}

    return compute_metrics


def train(args: argparse.Namespace) -> None:
    set_seed(args.seed)
    ds = load_samsum(sample_limit=args.sample_limit)
    model, tokenizer = build_model_and_tokenizer()

    tokenized = ds.map(
        lambda x: preprocess_batch(x, tokenizer),
        batched=True,
        remove_columns=ds["train"].column_names,
    )

    collator = DataCollatorForSeq2Seq(tokenizer=tokenizer, model=model)

    training_args = Seq2SeqTrainingArguments(
        output_dir=args.output_dir,
        num_train_epochs=args.epochs,
        per_device_train_batch_size=args.batch_size,
        per_device_eval_batch_size=args.batch_size,
        learning_rate=args.learning_rate,
        weight_decay=0.01,
        predict_with_generate=True,
        logging_steps=50,
        evaluation_strategy="epoch",
        save_strategy="epoch",
        save_total_limit=2,
        load_best_model_at_end=True,
        fp16=False,
        report_to="none",
    )

    trainer = Seq2SeqTrainer(
        model=model,
        args=training_args,
        train_dataset=tokenized["train"],
        eval_dataset=tokenized["validation"],
        tokenizer=tokenizer,
        data_collator=collator,
        compute_metrics=compute_metrics_builder(tokenizer),
    )

    trainer.train()
    trainer.save_model(args.output_dir)
    tokenizer.save_pretrained(args.output_dir)

    metrics = trainer.evaluate(tokenized["test"])
    os.makedirs(args.output_dir, exist_ok=True)
    with open(os.path.join(args.output_dir, "test_metrics.json"), "w", encoding="utf-8") as f:
        json.dump(metrics, f, indent=2)

    print("Training complete. Test metrics:")
    print(json.dumps(metrics, indent=2))


def evaluate_model(args: argparse.Namespace) -> None:
    set_seed(args.seed)
    ds = load_samsum(sample_limit=args.sample_limit)

    tokenizer = AutoTokenizer.from_pretrained(args.model_dir)
    model = EncoderDecoderModel.from_pretrained(args.model_dir)

    tokenized = ds.map(
        lambda x: preprocess_batch(x, tokenizer),
        batched=True,
        remove_columns=ds["test"].column_names,
    )

    collator = DataCollatorForSeq2Seq(tokenizer=tokenizer, model=model)
    eval_args = Seq2SeqTrainingArguments(
        output_dir=os.path.join(args.model_dir, "eval_tmp"),
        per_device_eval_batch_size=args.batch_size,
        predict_with_generate=True,
        report_to="none",
    )

    trainer = Seq2SeqTrainer(
        model=model,
        args=eval_args,
        eval_dataset=tokenized["test"],
        tokenizer=tokenizer,
        data_collator=collator,
        compute_metrics=compute_metrics_builder(tokenizer),
    )

    metrics = trainer.evaluate()
    with open(os.path.join(args.model_dir, "eval_metrics.json"), "w", encoding="utf-8") as f:
        json.dump(metrics, f, indent=2)

    print("Evaluation metrics:")
    print(json.dumps(metrics, indent=2))


def show_examples(args: argparse.Namespace) -> None:
    set_seed(args.seed)
    ds = load_samsum(sample_limit=max(args.num_examples, 20))
    test = ds["test"]

    tokenizer = AutoTokenizer.from_pretrained(args.model_dir)
    model = EncoderDecoderModel.from_pretrained(args.model_dir)

    count = min(args.num_examples, len(test))
    for idx in range(count):
        dialogue = test[idx]["dialogue"]
        reference = test[idx]["summary"]
        inputs = tokenizer(dialogue, return_tensors="pt", truncation=True, max_length=512)
        output_ids = model.generate(
            **inputs,
            num_beams=4,
            max_length=96,
            min_length=12,
            no_repeat_ngram_size=3,
        )
        prediction = tokenizer.decode(output_ids[0], skip_special_tokens=True)

        print(f"\nExample {idx + 1}")
        print("Dialogue:")
        print(dialogue)
        print("Reference:")
        print(reference)
        print("Prediction:")
        print(prediction)


def chatgpt_baseline(args: argparse.Namespace) -> None:
    api_key = os.getenv("OPENAI_API_KEY")
    if not api_key:
        raise RuntimeError("OPENAI_API_KEY is required for chatgpt command.")

    try:
        from openai import OpenAI
    except ImportError as exc:
        raise RuntimeError("Install openai package to run chatgpt baseline.") from exc

    set_seed(args.seed)
    ds = load_samsum(sample_limit=max(args.num_examples, 50))
    test = ds["test"]
    client = OpenAI(api_key=api_key)

    outputs = []
    count = min(args.num_examples, len(test))
    for idx in range(count):
        dialogue = test[idx]["dialogue"]
        reference = test[idx]["summary"]
        prompt = (
            "Summarize the following dialogue in 1 to 3 concise sentences. "
            "Keep key facts and decisions.\n\n"
            f"Dialogue:\n{dialogue}"
        )
        completion = client.chat.completions.create(
            model=args.openai_model,
            messages=[
                {"role": "system", "content": "You are an expert dialogue summarizer."},
                {"role": "user", "content": prompt},
            ],
            temperature=0.2,
        )
        pred = completion.choices[0].message.content.strip()
        outputs.append(
            {
                "dialogue": dialogue,
                "reference": reference,
                "prediction": pred,
            }
        )

    out_file = args.output_file or "chatgpt_baseline_outputs.json"
    with open(out_file, "w", encoding="utf-8") as f:
        json.dump(outputs, f, indent=2)
    print(f"Saved {len(outputs)} ChatGPT summaries to {out_file}")


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="Project 2 dialogue summarization pipeline.")
    subparsers = parser.add_subparsers(dest="command", required=True)

    train_parser = subparsers.add_parser("train", help="Train BERT2BERT on SAMSum.")
    train_parser.add_argument("--output_dir", type=str, required=True)
    train_parser.add_argument("--epochs", type=float, default=1.0)
    train_parser.add_argument("--batch_size", type=int, default=4)
    train_parser.add_argument("--learning_rate", type=float, default=5e-5)
    train_parser.add_argument("--sample_limit", type=int, default=0)
    train_parser.add_argument("--seed", type=int, default=42)

    eval_parser = subparsers.add_parser("eval", help="Evaluate a fine-tuned model.")
    eval_parser.add_argument("--model_dir", type=str, required=True)
    eval_parser.add_argument("--batch_size", type=int, default=4)
    eval_parser.add_argument("--sample_limit", type=int, default=0)
    eval_parser.add_argument("--seed", type=int, default=42)

    ex_parser = subparsers.add_parser("examples", help="Print qualitative prediction examples.")
    ex_parser.add_argument("--model_dir", type=str, required=True)
    ex_parser.add_argument("--num_examples", type=int, default=5)
    ex_parser.add_argument("--seed", type=int, default=42)

    gpt_parser = subparsers.add_parser("chatgpt", help="Generate optional ChatGPT baseline outputs.")
    gpt_parser.add_argument("--num_examples", type=int, default=20)
    gpt_parser.add_argument("--openai_model", type=str, default="gpt-4o-mini")
    gpt_parser.add_argument("--output_file", type=str, default="")
    gpt_parser.add_argument("--seed", type=int, default=42)

    return parser


def main() -> None:
    parser = build_parser()
    args = parser.parse_args()

    if args.command == "train":
        train(args)
    elif args.command == "eval":
        evaluate_model(args)
    elif args.command == "examples":
        show_examples(args)
    elif args.command == "chatgpt":
        chatgpt_baseline(args)
    else:
        raise ValueError(f"Unknown command: {args.command}")


if __name__ == "__main__":
    main()
