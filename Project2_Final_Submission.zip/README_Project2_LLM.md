# Project 2 Capstone - LLMs with AI

## Dialogue Summarization on SAMSum with BERT2BERT and ChatGPT Comparison

### Student Information
- Name: [Your Name]
- Program: Flatiron AI/ML
- Date: May 2026

## 1. Alignment with Project Brief

### Business Problem
Customer support teams, product teams, and marketplace analysts handle large volumes of conversational text (chat logs, support threads, and review discussions). Reading every dialogue manually is slow and inconsistent. The business need is an automatic summarization system that produces concise, informative summaries while preserving key actions, decisions, and outcomes.

### Proposed Solution
This project builds an end-to-end dialogue summarization pipeline using:
- A fine-tuned BERT-based encoder-decoder model on the SAMSum dataset.
- A ChatGPT autoregressive baseline for comparison.
- Quantitative evaluation with ROUGE and qualitative error analysis.

### Success Criteria
- Achieve strong ROUGE performance on SAMSum test data.
- Produce summaries that are concise, factual, and readable.
- Document model strengths, weaknesses, and deployment tradeoffs.

## 2. Technical Implementation

### Repository Files
- `project2_dialogue_summarization.py`: Training, evaluation, inference, and optional ChatGPT baseline generation.
- `README_Project2_LLM.md`: Final project report and run instructions.
- `PROJECT2_SUBMISSION_CHECKLIST.md`: Rubric mapping and final QA checks.

### Data
- Dataset: SAMSum (`samsum`) from Hugging Face Datasets.
- Input field: `dialogue`
- Target field: `summary`

### Model Architecture
- Primary model: BERT2BERT using Hugging Face `EncoderDecoderModel`.
- Encoder: `bert-base-uncased`
- Decoder: `bert-base-uncased` configured for seq2seq generation.
- Tokenization: WordPiece tokenizer from BERT.

### Training Approach
- Train/validation/test splits from SAMSum.
- Teacher-forced seq2seq training with `Seq2SeqTrainer`.
- Generation settings include beam search and length penalties.
- Optional reduced-sample training for faster iteration during development.

## 3. Evaluation and Analysis

### Metrics
- ROUGE-1
- ROUGE-2
- ROUGE-L
- ROUGE-Lsum

### Quantitative Results
Replace this table with your final measured scores.

| Model | ROUGE-1 | ROUGE-2 | ROUGE-L | ROUGE-Lsum |
|---|---:|---:|---:|---:|
| BERT2BERT (fine-tuned) | [fill] | [fill] | [fill] | [fill] |
| ChatGPT baseline | [fill] | [fill] | [fill] | [fill] |

### Qualitative Analysis
Include 3 to 5 examples where:
- The model performs well (captures intent and outcomes).
- The model misses details (speaker attribution, temporal info, rare entities).
- The model hallucinates or over-compresses context.

### Error Analysis Themes
- Long dialogue truncation and context loss.
- Pronoun/coreference ambiguity.
- Informal language and shorthand in chats.
- Numeric/detail omission in concise outputs.

## 4. Optimization and Iteration

### Implemented Improvements
- Batch size and learning rate tuning.
- Generation hyperparameter tuning (`num_beams`, `max_length`, `length_penalty`).
- Early stopping / best-model loading.
- Sample-size scaling from quick iteration subset to larger training runs.

### Recommended Next Improvements
- Domain-adaptive pretraining on conversational corpora.
- Better decoder initialization (for example, BART/T5 decoder alternatives).
- Distillation for faster inference.
- Factual consistency checks or constrained decoding.

## 5. Documentation and Reproducibility

### Environment Setup
Use a clean Python environment and install dependencies:

```powershell
python -m pip install -r requirements_project2.txt
```

### Train

```powershell
python project2_dialogue_summarization.py train --output_dir ./artifacts/bert2bert_samsum --epochs 1 --batch_size 4 --sample_limit 2000
```

### Evaluate

```powershell
python project2_dialogue_summarization.py eval --model_dir ./artifacts/bert2bert_samsum --sample_limit 500
```

### Generate Example Summaries

```powershell
python project2_dialogue_summarization.py examples --model_dir ./artifacts/bert2bert_samsum --num_examples 5
```

### Optional ChatGPT Baseline
Set `OPENAI_API_KEY` first.

```powershell
python project2_dialogue_summarization.py chatgpt --num_examples 20 --openai_model gpt-4o-mini
```

## 6. Final Submission Contents

Your final GitHub repository should include:
- Jupyter Notebook containing end-to-end workflow, outputs, and discussion.
- This README report (`README.md` at repo root for final submission).
- Source code used for training/evaluation.
- Clear run instructions and dependency list.

## 7. Rubric Mapping

### Alignment with Project Brief
- Problem, stakeholder impact, and business value are explicitly defined.

### Technical Implementation
- End-to-end pipeline implemented with transformer-based seq2seq architecture.

### Evaluation and Analysis
- ROUGE + qualitative analysis + limitations and improvement plan.

### Documentation and Report
- Reproducible setup, commands, outputs, and clear narrative.

## 8. Conclusion
This project delivers a practical dialogue summarization system based on transformer models and provides a direct comparison to a ChatGPT-style autoregressive baseline. The result is a deployable workflow for condensing conversations into clear, actionable summaries, with transparent evaluation and improvement pathways.
